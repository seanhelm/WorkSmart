package com.cs321.group7.worksmart;

import android.arch.persistence.room.Room;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.cs321.group7.worksmart.Entities.Semester;
import com.cs321.group7.worksmart.Entities.Class;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static junit.framework.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class ClassTest
{
    private AppDatabase appDB;

    @Before
    public void setUp() throws Exception
    {
        // Don't use this in actual code because it only stores in memory (used for testing)
        // Use GetDB instead
        appDB = Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getContext(),
                AppDatabase.class).build();

        Semester semester = new Semester("Fall 2016");
        appDB.semesterDao().insert(semester);
    }

    @After
    public void shutDown() throws Exception
    {
        appDB.close();
    }

    @Test
    public void createAndVerifyClass()
    {
        List<Semester> semesters = appDB.semesterDao().getAll();
        Semester sem = semesters.get(0);

        Class c = new Class("CS 101", "John", "email@email.com",
                "AB 123", "6 pm", sem.getId());
        appDB.classDao().insert(c);

        List<Class> classes = appDB.classDao().getAll(sem.getId());
        c = classes.get(0);

        assertEquals("CS 101", c.getName());
    }

    @Test
    public void updateAndVerifyClass()
    {
        List<Semester> semesters = appDB.semesterDao().getAll();
        Semester sem = semesters.get(0);

        Class c = new Class("CS 101", "John", "email@email.com",
                "AB 123", "6 pm", sem.getId());
        appDB.classDao().insert(c);

        List<Class> classes = appDB.classDao().getAll(sem.getId());
        c = classes.get(0);

        c.setName("HIST 100");
        appDB.classDao().update(c);

        classes = appDB.classDao().getAll(sem.getId());
        c = classes.get(0);

        assertEquals("HIST 100", c.getName());
    }
}
